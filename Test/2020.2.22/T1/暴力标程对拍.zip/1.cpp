#include<bits/stdc++.h>
#define int long long
#define MK 100010
using namespace std;
int n,sum[MK];
char s[MK];

int work(int x)
{
	int res = 0;
	int k = sum[n-1]/x;
	for(int i=0;i<n;i++)
	{
		if(s[i]!='0' && sum[i]%k==0)
		{
			res++;
		}
	}
	if(res>=x)
	{
		return 1;
	}else
	{
		return 0;
	}
}

signed main()
{
	while(~scanf("%lld%s",&n,s))
	{
		memset(sum,0,sizeof(sum));
		int cnt = 0;
		int ch = s[0]-'0';
		sum[0] = ch;
		if(ch!=0)
		{
			cnt++;
		}
		for(int i=1;i<n;i++)
		{
			ch = s[i]-'0';
			if(ch!=0)
			{
				cnt++;
			}
			sum[i] = sum[i-1]+ch;
		}
		int flag = 0;
		if(cnt==0)
		{
			flag = 1;
		}
		if(!flag)
		{
			for(int i=2;i<=n;i++)
			{
				if(sum[n-1]%1==0)
				{
					int ans = work(i);
					if(ans)
					{
						flag = 1;
						break;
					}
				}
			}
		}
		if(flag)
		{
			printf("YES\n");
		}else
		{
			printf("NO\n");
		}
	}
	return 0;
}